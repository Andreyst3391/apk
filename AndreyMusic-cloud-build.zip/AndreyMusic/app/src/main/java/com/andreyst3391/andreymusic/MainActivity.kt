package com.andreyst3391.andreymusic

import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken

private val Ink = Color(0xFF101018)
private val Violet = Color(0xFF8B5CF6)
private val Pink = Color(0xFFFF4F9A)
private val Cyan = Color(0xFF42D9E8)

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var selectedName by mutableStateOf("Ничего не играет")
    private var isPlaying by mutableStateOf(false)
    private var controllerFuture: com.google.common.util.concurrent.ListenableFuture<MediaController>? = null
    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
        override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) {
            mediaMetadata.title?.let { selectedName = it.toString() }
        }
    }

    private val audioPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { playUri(it) }
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                controller = runCatching { future.get() }.getOrNull()
                controller?.addListener(playerListener)
                isPlaying = controller?.isPlaying == true
            }, mainExecutor)
        }
    }

    override fun onStop() {
        controller?.removeListener(playerListener)
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onStop()
    }

    private fun playUri(uri: Uri) {
        runCatching {
            contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        selectedName = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "Аудиофайл"
        controller?.apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            play()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                PlayerScreen(
                    title = selectedName,
                    playing = isPlaying,
                    onPick = { audioPicker.launch(arrayOf("audio/*")) },
                    onPlayPause = { controller?.let { if (it.isPlaying) it.pause() else it.play() } },
                    onNext = { controller?.seekToNextMediaItem() }
                )
            }
        }
    }
}

@Composable
private fun PlayerScreen(
    title: String,
    playing: Boolean,
    onPick: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit
) {
    val transition = rememberInfiniteTransition(label = "ambient")
    val drift by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "drift"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.985f, targetValue = 1.025f,
        animationSpec = infiniteRepeatable(tween(if (playing) 1500 else 3200), RepeatMode.Reverse),
        label = "pulse"
    )
    val rotation by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(18000, easing = androidx.compose.animation.core.LinearEasing)),
        label = "rotation"
    )

    Box(Modifier.fillMaxSize().background(Ink)) {
        Canvas(Modifier.fillMaxSize()) {
            val x = size.width * (0.18f + drift * 0.48f)
            val y = size.height * (0.22f + (1f - drift) * 0.30f)
            drawCircle(Brush.radialGradient(listOf(Violet.copy(alpha = 0.42f), Color.Transparent), center = Offset(x, y), radius = size.width * 0.72f), radius = size.width * 0.72f, center = Offset(x, y))
            drawCircle(Brush.radialGradient(listOf(Pink.copy(alpha = 0.22f), Color.Transparent), center = Offset(size.width * (0.88f - drift * 0.2f), size.height * 0.72f), radius = size.width * 0.62f), radius = size.width * 0.62f, center = Offset(size.width * (0.88f - drift * 0.2f), size.height * 0.72f))
        }

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("ANDREY MUSIC", color = Color.White, fontSize = 20.sp)
                Spacer(Modifier.weight(1f))
                Text("VIVO EDITION", color = Color(0xFFB9A8E8), fontSize = 10.sp, letterSpacing = 2.sp)
            }
            Spacer(Modifier.height(30.dp))
            AnimatedAlbumArt(rotation = rotation, pulse = if (playing) pulse else 1f)
            Spacer(Modifier.height(30.dp))
            Text("СЕЙЧАС ИГРАЕТ", color = Color(0xFFBBAED0), fontSize = 11.sp, letterSpacing = 3.sp)
            Spacer(Modifier.height(10.dp))
            Text(title, color = Color.White, fontSize = 22.sp, textAlign = TextAlign.Center, maxLines = 2)
            Spacer(Modifier.height(8.dp))
            Text(if (playing) "Музыка звучит" else "Пауза", color = Color(0xFFBBAED0), fontSize = 13.sp)
            Spacer(Modifier.height(24.dp))
            EqualizerBars(active = playing)
            Spacer(Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                FilledTonalButton(onClick = onPick, shape = CircleShape, contentPadding = PaddingValues(16.dp)) {
                    Icon(Icons.Default.FolderOpen, contentDescription = "Выбрать файл")
                }
                Button(onClick = onPlayPause, shape = CircleShape, modifier = Modifier.size(72.dp), contentPadding = PaddingValues(0.dp)) {
                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = "Воспроизвести или пауза", modifier = Modifier.size(34.dp))
                }
                FilledTonalButton(onClick = onNext, shape = CircleShape, contentPadding = PaddingValues(16.dp)) {
                    Icon(Icons.Default.SkipNext, contentDescription = "Следующий трек")
                }
            }
            Spacer(Modifier.height(28.dp))
            Text("Выбери музыку на телефоне и включи своё настроение.", color = Color(0xFFB8B4C4), fontSize = 12.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Text("Origin Island зависит от поддержки медиасессий прошивкой vivo.", color = Color(0xFF8E899C), fontSize = 10.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun AnimatedAlbumArt(rotation: Float, pulse: Float) {
    Box(
        Modifier.size(276.dp).scale(pulse).clip(RoundedCornerShape(34.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF32205D), Color(0xFFB83280), Color(0xFF174D70)))),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = size.minDimension * 0.36f
            drawCircle(Brush.radialGradient(listOf(Color(0xFFFFC1E1).copy(alpha = 0.85f), Pink.copy(alpha = 0.3f), Color.Transparent), center, radius * 1.9f), radius * 1.9f, center)
            drawCircle(Color(0xFF171522).copy(alpha = 0.78f), radius, center)
            for (i in 1..5) {
                drawCircle(Color.White.copy(alpha = 0.10f - i * 0.012f), radius * (i / 5f), center, style = Stroke(width = 1.5.dp.toPx()))
            }
            drawCircle(Color.White.copy(alpha = 0.55f), radius * 0.09f, center)
            val angle = Math.toRadians(rotation.toDouble())
            val end = Offset(center.x + kotlin.math.cos(angle).toFloat() * radius * 0.82f, center.y + kotlin.math.sin(angle).toFloat() * radius * 0.82f)
            drawLine(Color.White.copy(alpha = 0.8f), center, end, strokeWidth = 3.dp.toPx())
            drawCircle(Color.White.copy(alpha = 0.28f), radius * 1.28f, center, style = Stroke(width = 2.dp.toPx()))
        }
        Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("A", color = Color.White.copy(alpha = 0.85f), fontSize = 34.sp)
            Text("ANDREY MUSIC", color = Color.White.copy(alpha = 0.75f), fontSize = 9.sp, letterSpacing = 3.sp)
        }
    }
}

@Composable
private fun EqualizerBars(active: Boolean) {
    val transition = rememberInfiniteTransition(label = "equalizer")
    val heights = (0..20).map { index ->
        val target = if (active) (0.25f + ((index * 17 % 9) / 12f)) else 0.12f
        transition.animateFloat(
            initialValue = 0.12f, targetValue = target,
            animationSpec = infiniteRepeatable(tween(if (active) 350 + index * 27 else 1800), RepeatMode.Reverse),
            label = "bar$index"
        ).value
    }
    Row(Modifier.height(30.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
        heights.forEach { h ->
            Box(Modifier.width(3.dp).fillMaxHeight(h).clip(CircleShape).background(Brush.verticalGradient(listOf(Pink, Violet, Cyan))))
        }
    }
}
